import './style.css';
import store from './store.js';

document.querySelector('#app').innerHTML = `

  <div style="font-size:24px;">
    <button id="dec">-</button>
    <span id="count">0</span>
    <button id="inc">+</button>
  </div>
`;

const countEl = document.getElementById('count');

function render() {
  countEl.textContent = store.getState().count;
}

render();

store.subscribe(render);

document.getElementById('inc').addEventListener('click', () => {
  store.dispatch({ type: 'INCREMENT' });
});

document.getElementById('dec').addEventListener('click', () => {
  store.dispatch({ type: 'DECREMENT' });
});
